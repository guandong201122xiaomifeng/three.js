import React,{useState, } from 'react'
// import useLoadData from '../utils/useLoadData'
import useSelfReducer from '../utils/useSelfReducer'
function UseSelfHook(){
    // const [num, setNum] = useLoadData()
    const [state, dispatch] = useSelfReducer()
    return (
        <div>
            {/* <div
            onClick = {() => {setNum(oldNum => oldNum + 1)}}
            >{num}</div> */}
            <div onClick={() => {dispatch({type:'changeAge',age: 20})}}>state.age -- {state.age}</div>
        </div>
    )
}
export default UseSelfHook

// 定义Hook
// 1. 引入需要的hook
// 2. 创建自己的hook
// 3. 返回一个数组，数组有两个参数，第一个是数据，第二个是修改数据的方法
// 4. 把方法暴露出去

// 使用Hookbmmnnmnmnmnmnm
// 5. 在组件里使用hook,