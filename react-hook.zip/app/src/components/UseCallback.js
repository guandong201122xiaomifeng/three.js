import React,{useCallback, useEffect, useState,} from 'react'
const set = new Set()//集合中不能存储相同的内容
function MemoFunction(){
    const [name, setName] = useState('小明')
    const [num, setNum] = useState(1)
    // function getDoubleNum (){
    //     console.log('getDoubleNum')
    //     return 2 * num
    // }

    // useMemo返回的是一个值，useCallback返回的是一个函数，依赖项为[]的时候，每次函数在跑，但是页面却没更新
    // useMemo缓存的是一个值，useCallback缓存的是一个函数，当依赖项没变化的时候，useCallback缓存的是同个函数，执行后结果一样，页面没更新。
    const getThreeNum = useCallback(() => {
        console.log('getThreeNum')
        return 2 * num
    }, [num])
    console.log(set.size)
    set.add(getThreeNum)
    console.log(set.size) //如果getThreeNum变化，set.size会加一
    return (
        <div>
            <div onClick = {() => {setName(oldName => oldName + 1)}}>{name}</div>
            <div onClick = {() => {setNum(oldNum => oldNum + 1)}}>
                {num}
                {/* getDoubleNum:{getDoubleNum()} */}
                getThreeNum:{getThreeNum()}
            </div>
            <Child callback = {getThreeNum}/>
        </div>
    )
}

// 当props.callback变化的时候，才会重新渲染，如果不变化，会执行，但不会重新渲染。
function Child(props){
    useEffect(() => {
        console.log('callback更新了')
    },[props.callback])
    // console.log(props.callback)
    return <div>child</div>
}
export default MemoFunction