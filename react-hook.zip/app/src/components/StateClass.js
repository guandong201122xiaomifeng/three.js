import React from 'react'
class StateClass extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            name: '类'
        }
    }
    componentDidMount(){
        console.log('类组件渲染结束')
    }
    render(){
        return (<div>
            {this.state.name}
        </div>)
    }
}
export default StateClass