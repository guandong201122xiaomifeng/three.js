import React,{useCallback, useEffect, useState,useRef} from 'react'
function UseRef(){
    const [name, setName] = useState('小明')
    const [num, setNum] = useState(1)
    const ref = useRef()
    console.log('ref', ref) //{current: undefined}
    let timer
    useEffect(() => {
        // timer = setInterval(() => {
        //     if(num > 10){
        //         // 这里获取的num每次都是第一次渲染的num,即1，不会进来这里
        //         console.log('超过10了', timer)
        //         clearInterval(timer)
        //         return
        //     }
        //     setNum(oldNum => oldNum + 1)
        // }, 500)
        ref.current = setInterval(() => {
            if(num > 10){
                // 这里获取的num每次都是第一次渲染的num,即1，不会进来这里
                console.log('超过10了', timer)
                clearInterval(timer)
                return
            }
            setNum(oldNum => oldNum + 1)

            // ref.current = '123' //不会触发视图更新
        }, 500)
    }, [])
    useEffect(() => {
        if(num > 10){
            // console.log('超过10了', timer)
            // // timer 是undefined,不是定时器，因为在正常渲染中，timer丢失了，要使用useRef
            // clearInterval(timer)
            // ref.current='456'
            console.log('超过10了', ref.current)
            clearInterval(ref.current)
            
        }
    }, [num])
    return (
        <div>
            <div onClick = {() => {setName(oldName => oldName + 1)}}>{name}</div>
            <div onClick = {() => {setNum(oldNum => oldNum + 1)}}>{num}</div>
            <div>
                {num}
            </div>
            <div>ref.current:{ref.current}</div>
        </div>
    )
}
export default UseRef