import React,{useState, } from 'react'
import useLoadData from '../utils/useLoadData'
function UseSelfHook(){
    const [num, setNum] = useLoadData()
    return (
        <div>
            <div
            onClick = {() => {setNum(oldNum => oldNum + 1)}}
            >{num}</div>
        </div>
    )
}
export default UseSelfHook