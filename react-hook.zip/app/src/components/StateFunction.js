import React,{useState, useEffect, useLayoutEffect,useRef} from 'react'
function StateFunction(){


    const [name, setName] = useState('函数')
    const [num, setNum] = useState(1)
    // useEffect(() => {
    //     console.log('函数组件结束渲染。')
    //     // 第二个参数是副作用的依赖列表，只有里面
    //     // 的依赖项发生变化的时候，才会触发副作用函数
    // },[num])

    useEffect(() => {
        console.log('函数组件结束渲染。')
        // 第二个参数为空数组，则无论这里面什么状态变化了，
        // 都不执行副作用，也就是说只执行一次
    },[])

    // 如果副作用返回一个函数a，则每次执行副作用之前都会执行这个函数a
    // 第一次执行副作用时，不会执行a,可以在a里做一些销毁需要做的事情，
    // 比如事件解绑,确保不重复绑定事件

    // useEffect(() => {
    //     document.body.addEventListener('click', function () {
    //         console.log('click body')
    //     })
    //     console.log('函数组件结束渲染。')
    //     return function a(){
    //         document.body.removeEventListener('click', function (){
    //             console.log('remove body click')
    //         },false)
    //         console.log('销毁')
    //     }
    // },[num])

    // useEffect(() => {
    //     console.log('useEffect')
    //     setNum(13)
    // },[num])
    // useLayoutEffect(() => {
    //     console.log('useLayoutEffect')
    //     // setNum(14)
    //     return () => {
    //         console.log('useLayoutEffect return function')
    //     }
    // },[num])
    return (
        <div>
            <div onClick = {() => {setName('小函数')}}>这是函数组件 - {name}</div>
            <div onClick = {() => {setNum(oldNum => oldNum + 1)}}>{num}</div>
        </div>
    )
}
export default StateFunction