import React,{useMemo, useState,} from 'react'
function MemoFunction(){
    const [name, setName] = useState('小明')
    const [num, setNum] = useState(1)
    function getDoubleNum (){
        console.log('getDoubleNum')
        return 2 * num
    }
    const getThreeNum = useMemo(() => {
        console.log('getThreeNum')
        return 2 * num
    },[name])
    return (
        <div>
            <div onClick = {() => {setName(oldName => oldName + 1)}}>{name}</div>
            <div onClick = {() => {setNum(oldNum => oldNum + 1)}}>
                {num}
                getDoubleNum:{getDoubleNum()}
                getThreeNum:{getThreeNum}
            </div>
        </div>
    )
}
export default MemoFunction