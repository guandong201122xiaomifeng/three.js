import React,{useState, useReducer} from 'react'
const store = {
    num: 10
}
const reducer = (state, action) => {
    switch (action.type) {
        case 'changeNum':
            return {
                ...state,
                num: state.num + action.num
            }
        default :
            return {
                ...state
            };
    }
}
function UseReducer(){
    const [state, dispatch] = useReducer(reducer, store)
    // const [num, setNum] = useState(1)
    return (
        <div>
            <div onClick = {() => {
                dispatch({
                    type: 'changeNum',
                    num: 100
                })
            }}>{state.num}</div>
            
        </div>
    )
}
export default UseReducer