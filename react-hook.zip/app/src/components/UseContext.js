import React,{useState, useContext, createContext} from 'react'
// 创建context句柄
const Context = createContext(null)
function UseContext(){
    const [num, setNum] = useState(1)
    return (
        <div>
            <div onClick = {() => {setNum(oldNum => oldNum + 1)}}>{num}</div>
            <Item1 num={num}/>
            <Item2 num={num}/>
            {/* value传共享值 */}
            <Context.Provider value={num}>
                {/* 数据共享范围 */}
                <Item3/>
                <Item4/>
            </Context.Provider>
        </div>
    )
}
function Item1(props){
    return <div>子组件{props.num}</div>
}
function Item2(props){
    return <div>子组件{props.num}</div>
}
function Item3(){
    // 读取共享的值
    const value = useContext(Context)
    console.log('value', value)
    return <div>子组件3{value}</div>
}
function Item4(){
    return <div>子组件4</div>
}
export default UseContext