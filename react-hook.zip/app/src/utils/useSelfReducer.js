import React, {useReducer} from 'react'
const store = {
    age: 10
}
const reducer = (state, action) => {
    switch (action.type) {
        case 'changeAge':
            return {
                ...state,
                age: action.age
            }
        default :
            return {
                ...state
            };
    }
}
function useSelfReducer(){
    const [state, dispatch] = useReducer(reducer, store)
    return [state, dispatch]
}
export default useSelfReducer