import React,{useEffect, useState} from 'react'
function useLoadData (){
    const [num, setNum] = useState(1)
    useEffect(() => {
        setTimeout(() => {
            setNum(10)
        }, 1000)
    }, [])
    return [
        num,
        setNum
    ]
}
export default useLoadData