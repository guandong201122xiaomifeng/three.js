import logo from '../images/logo.svg';
import './App.css';
import StateClass from '../components/StateClass'
import StateFunction from '../components/StateFunction'
import MemoFunction from '../components/UseMemo'
import UseCallback from '../components/UseCallback'
import UseRef from '../components/UseRef'
import UseContext from '../components/UseContext'
import UseReducer from '../components/UseReducer'
import UseSelfHook from '../components/UseSelfHook'
import UseSelfReducer from '../components/UseSelfReducer'
function App() {
  return (
    <div className="App">
      {/* <StateClass/> */}
      {/* <StateFunction/> */}
      {/* <MemoFunction/> */}
      {/* <UseCallback/> */}
      {/* <UseRef/> */}
      {/* <UseContext/> */}
      <UseReducer/>
      {/* <UseSelfHook/> */}
      {/* <UseSelfReducer/> */}
    </div>
  );
}

export default App;
