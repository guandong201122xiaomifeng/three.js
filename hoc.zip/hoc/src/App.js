// import logo from './logo.svg';
import './App.css';
import A from './components/A'
import B from './components/B'
import C from './components/C'
import E from './components/E'
import F from './components/F'
function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <A name="xiaoming" age={12}/>
        <B name="xiaoming" age={12}/>
        <C name="xiaoming" age={12}/> */}
        <E/>
        <F/>
        {/* <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a> */}
      </header>
    </div>
  );
}

export default App;
