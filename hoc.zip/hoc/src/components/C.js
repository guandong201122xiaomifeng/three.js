import React, { Component } from 'react';
import d from './d'
@d
class C extends Component {
    getName(){
        return '我是C组件'
    }
    render() {
        return (
            <div>
                C
            </div>
        );
    }
}

export default C;