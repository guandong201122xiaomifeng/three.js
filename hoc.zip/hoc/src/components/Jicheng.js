import React from 'react'
const modifyPropsHOC = (WrapComponent) => class NewComponent extends WrapComponent {
    // 每个react class都有个displayName,默认是类的名字
    static displayName = `NewComponent(${displayName(WrapComponent)})`
    // componentWillMount(){
    //     alert('我是修改后生命周期')
    // }
    render(){
        // 拿出渲染的元素
        const element = super.render()
        // 如果元素是div就给个背景色，如果不是就给另外的背景色
        const newStyle = {
            color: element.type === 'div'? 'red' : 'green'
        }
        const newProps = {...this.props,style: newStyle }
        // console.log('element',element, 'newProps',newProps, 'element.props.children',element.props.children)
        
        // 三个参数，element, props, 子元素
        return React.cloneElement(element, newProps, element.props.children)
        // return React.cloneElement(element, newProps, '123')
    }
}
function displayName(WrapComponent){
    return WrapComponent.displayName || WrapComponent.name || 'Component'
}
export default modifyPropsHOC