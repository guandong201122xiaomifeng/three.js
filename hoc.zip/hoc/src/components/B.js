import React, { Component } from 'react';
import d from './d'
@d
class B extends Component {
    // constructor(props){
    //     super(props)
    //     this.state = {
    //         value: ''
    //     }
    // }
    // changeInput(e){
    //     this.setState({
    //         value: e.target.value
    //     })
    // }
    render() {
        return (
            <div>
                {/* <input value={this.state.value} onInput={this.changeInput.bind(this)}/> */}
                <input {...this.props}/>
                <br/>
                <p>B</p>
                <p>name: {this.props.name}</p>
                <p>age: {this.props.age}</p>
                <p>sex: {this.props.sex}</p>
            </div>
        );
    }
}

// export default d(B);
export default B;
