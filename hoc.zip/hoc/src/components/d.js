import React from 'react'

function d(Comp){
    // 除age之外的属性
    return class D extends React.Component {
        constructor(props){
            super(props)
            this.state = {
                value: ''
            }
        }
        onInput = (e) => {
            this.setState({
                value: e.target.value
            })
            console.log(this.state.value)
        }
        refc(instance){
            // instance.getName && alert(instance.getName())
        }
        render () {
            const stateProps = {
                value: this.state.value,
                onInput: this.onInput
            }
            const { age, ...otherProps } = this.props
            return (
                <div>
                    我是高阶组件ddd
                    {/* <Comp sex="男" {...this.props}/> */}
                    <Comp sex="男" {...otherProps} ref={this.refc.bind(this)} {...stateProps}/>
                </div>
            )
        }
    }
}
export default d