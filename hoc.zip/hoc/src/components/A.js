import React, { Component } from 'react';
class A extends Component {
    render() {
        return (
            <div>
                <p>A</p>
                <p>name: {this.props.name}</p>
                <p>age: {this.props.age}</p>
            </div>
        );
    }
}

export default A;