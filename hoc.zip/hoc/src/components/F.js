import React, { Component } from 'react';
import Jicheng from './Jicheng'

@Jicheng
class F extends Component {
    render() {
        return (
            <p>
                我F是p
            </p>
        );
    }
}

export default F;