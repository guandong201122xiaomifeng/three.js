import React, { Component } from 'react';
import Jicheng from './Jicheng'

@Jicheng
class E extends Component {
    // componentWillMount(){
    //     alert('我是原始生命周期')
    // }
    render() {
        return (
            <div>
                我E是div
                <p>E的子元素</p>
            </div>
        );
    }
}

export default E;