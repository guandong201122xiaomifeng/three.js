setTimeout(function(){
    console.log('hello')
}, 1000)
console.log(1)