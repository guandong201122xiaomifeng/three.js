# redis-test

npm redis 版本升级之后，连接数据库的写法不一样了，具体参考 `index.js`
