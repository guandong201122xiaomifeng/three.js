# mongodb test

## 2022 升级 1

升级 `mongoose` 最新版之后，不再支持 `useFindAndModify` `useNewUrlParser` `useUnifiedTopology`

## 2022 升级 2

Mac OS 如果执行 brew 遇到报错：unknown or unsupported macOS version ，可执行 `brew update` 来修复
