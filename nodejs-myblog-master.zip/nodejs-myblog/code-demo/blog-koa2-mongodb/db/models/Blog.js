// 对应 blog 集合

const mongoose = require('../db')

const BlogSchema = mongoose.Schema({
    title: {
        type: String,
        required: true // 必需
    },
    content: String,
    author: {
        type: String,
        required: true
    }
}, { timestamps: true })

const Blog = mongoose.model('blog', BlogSchema)

module.exports = Blog
