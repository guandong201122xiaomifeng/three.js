const { genPassword } = require('./utils/cryp')

console.log( genPassword('123') )